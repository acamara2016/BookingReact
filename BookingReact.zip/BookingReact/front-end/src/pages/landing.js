import React,  {useEffect} from 'react';

import Hot from '../components/Hot';

const cards = [1, 2, 3, 4, 5, 6, 7, 8, 9];
const axios = require('axios');

export default class Landing extends React.Component{
    constructor(props) {
        super(props);
        this.state = { 
            apiResponse: [],
            result: []
        };
    }
    callAPI() {
        fetch("http://localhost:9000/movies&alt=json")
            .then(res => res.json())
            .then(res => this.setState({ apiResponse: res }));
    }
       getFromLoblaws = () => {
            axios.get("http://localhost:9000/movies")
            .then(({ data }) => {
                this.setState({
                result: data                   
                })
            })
        }
    
    componentDidMount() {
        this.getFromLoblaws();
    }
    render(){
        
        return (
            <React.Fragment>
                <div className="container-fluid">
                    {/**Hot movies */}
                    <Hot data={this.state.result}/>
                </div>
            </React.Fragment>
        );
    }

}