import React from 'react';

export default function Hot(props){
    var result = props.data.slice(0,5)
    return(
        <div id="hot">
            <p>{props.data.slice(0,5).length}</p>
            {result.map((movie)=>(
                <div key={movie.id} class="card" style={{width: '18rem'}}>
                    <img src={movie.posters} class="card-img-top" alt="..."/>
                    <div class="card-body">
                        <h5 class="card-title">{movie.title}</h5>
                        <p class="card-text">{movie.plot}</p>
                        <a href="#" class="btn btn-primary">Get a ticket</a>
                    </div>
                </div>
            ))}
            {/* {props.data.map((movie)=>(
                <div key={movie.id} class="card" style="width: 18rem;">
                    <img src={movie.posters} class="card-img-top" alt="..."/>
                    <div class="card-body">
                        <h5 class="card-title">{movie.title}</h5>
                        <p class="card-text">{movie.plot}</p>
                        <a href="#" class="btn btn-primary">Get a ticket</a>
                    </div>
              </div>
            ))} */}
            {/* {cards.map((card) => (
              
            ))} */}
        </div>
    );
}