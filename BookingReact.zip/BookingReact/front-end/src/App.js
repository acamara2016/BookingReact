import './App.css';
import Landing from './pages/landing';

function App() {
  return (
    <div className="BookEvent">
      <Landing/>
    </div>
  );
}

export default App;
